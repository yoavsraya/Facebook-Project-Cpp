#include "Data.h"
#include <iostream>
using namespace std;

int main()
{
	Facebook program; // main class
	program.starterFunc(); // set 3 friends and pages
	program.runMenu(); // run facebook menu
	return 0;
}